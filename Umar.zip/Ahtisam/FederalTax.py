import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector

# --- DATABASE CONNECTION ---
def get_db_connection():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",         
            password="=w3-y2p!Qb45+$E", # Your MySQL password
            database="Federal_Tax_DB"
        )
    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Error: {err}")
        return None

class TaxSystemApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Federal Tax Management System")
        self.root.geometry("900x500")

        # --- UI STYLING ---
        style = ttk.Style()
        style.configure("Treeview.Heading", font=('Arial', 10, 'bold'))

        # --- TOP SEARCH SECTION ---
        search_frame = tk.Frame(self.root, pady=20)
        search_frame.pack(side=tk.TOP, fill=tk.X)

        tk.Label(search_frame, text="Search by SSN:", font=('Arial', 10)).pack(side=tk.LEFT, padx=10)
        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(search_frame, textvariable=self.search_var, width=20)
        self.search_entry.pack(side=tk.LEFT, padx=5)

        btn_search = tk.Button(search_frame, text="Search", command=self.search_taxpayer, bg="#4CAF50", fg="white")
        btn_search.pack(side=tk.LEFT, padx=5)

        btn_refresh = tk.Button(search_frame, text="Show All", command=self.load_data)
        btn_refresh.pack(side=tk.LEFT, padx=5)

        # --- TABLE SECTION (TREEVIEW) ---
        table_frame = tk.Frame(self.root)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        columns = ("id", "ssn", "fname", "lname", "email", "status")
        self.tree = ttk.Treeview(table_frame, columns=columns, show='headings')

        # Define Headings
        self.tree.heading("id", text="ID")
        self.tree.heading("ssn", text="SSN")
        self.tree.heading("fname", text="First Name")
        self.tree.heading("lname", text="Last Name")
        self.tree.heading("email", text="Email")
        self.tree.heading("status", text="Filing Status")

        # Column widths
        self.tree.column("id", width=30)
        self.tree.column("ssn", width=100)
        self.tree.column("fname", width=120)
        self.tree.column("lname", width=120)
        self.tree.column("email", width=200)
        
        self.tree.pack(fill=tk.BOTH, expand=True)

        # Initial Load
        self.load_data()

    def load_data(self):
        """Fetches all taxpayers from MySQL and displays them in the Treeview."""
        self.tree.delete(*self.tree.get_children()) # Clear table
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Taxpayer")
            rows = cursor.fetchall()
            for row in rows:
                self.tree.insert("", tk.END, values=row)
            conn.close()

    def search_taxpayer(self):
        """Filters the table based on the SSN entered."""
        ssn = self.search_var.get()
        if not ssn:
            messagebox.showwarning("Input Error", "Please enter an SSN to search.")
            return

        self.tree.delete(*self.tree.get_children())
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor()
            # Using parameterized query to prevent SQL Injection
            query = "SELECT * FROM Taxpayer WHERE SSN = %s"
            cursor.execute(query, (ssn,))
            rows = cursor.fetchall()
            
            if rows:
                for row in rows:
                    self.tree.insert("", tk.END, values=row)
            else:
                messagebox.showinfo("Not Found", "No taxpayer found with that SSN.")
                self.load_data()
            conn.close()

# --- MAIN LOOP ---
if __name__ == "__main__":
    root = tk.Tk()
    app = TaxSystemApp(root)
    root.mainloop()